<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div style="width:95%">
	<p>
		You are using the Lite version of the Gallery Video for WordPress. If you want to get more awesome options,
		advanced features, settings to customize every area of the plugin, then check out the Full License plugin. The
		full version of the plugin is available in 3 different packages of one-time payment.
	</p>
	<br/><br/>
	<a href="http://huge-it.com/wordpress-video-gallery/" class="button-primary" target="_blank">Purchase a License</a>
	<br/><br/><br/>
	<p>After the purchasing the commercial version follow this steps:</p>
	<ol>
		<li>Deactivate Huge IT Video Gallery Plugin</li>
		<li>Delete Huge IT Video Gallery Plugin</li>
		<li>Install the downloaded commercial version of the plugin</li>
	</ol>
</div>