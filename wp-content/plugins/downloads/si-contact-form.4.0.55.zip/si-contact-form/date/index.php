<?php
// Silence is golden. Do not delete this file to keep your inner balance.